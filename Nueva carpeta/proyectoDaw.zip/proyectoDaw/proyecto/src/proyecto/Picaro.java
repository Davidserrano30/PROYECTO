package proyecto;

import javax.swing.JPanel;
import java.awt.Color;

public class Picaro extends JPanel {

	/**
	 * Create the panel.
	 */
	public Picaro() {
		setBackground(new Color(255, 0, 0));
		setLayout(null);

	}

}
